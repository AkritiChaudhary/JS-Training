document.getElementById("h1").innerHTML=<b>"Welcome to my site!"</b>;
document.getElementById("p1").innerText=  "My name is Akriti";
document.getElementById("h2").innerHTML="";
document.getElementById("p2").innerText="I love JavaScript";
document.getElementById("p2").style.color="blue";


